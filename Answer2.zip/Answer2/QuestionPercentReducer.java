package QuestionTimes;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
//import java.util.Iterator;
//import java.util.NavigableMap;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeMap;
//import java.util.Set;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.commons.collections.map.MultiValueMap;




public class QuestionPercentReducer extends Reducer<Text,IntWritable,Text,IntWritable> 
{

	//Text outkey = new Text();
	//DoubleWritable outvalue = new DoubleWritable();
	//private Map countMap = new HashMap<>();
	TreeMap<Integer, String> treemap = new TreeMap<Integer, String>();
	 MultiValueMap mvm = new MultiValueMap();
	public void reduce(Text key , Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
	{
		
		int count = 0;
		//String ques;
		
		for (IntWritable value:values){
			
			count = count+value.get();
			
		}
		
        treemap.put(count,key.toString());
		mvm.put(count,key.toString());
				
		//context.write(key, new IntWritable(count)); 
		
	
	}
	
	@Override
    protected void cleanup(Context context) throws IOException, InterruptedException {

       // Map sortedMap = sortByValues(countMap);
		   //NavigableMap nset=treemap.descendingMap();
		   
		Set<Integer> keys = treemap.descendingKeySet();
		   

        for(Integer key: keys){
            //String value = treemap.get(key);
           List list = (List) mvm.get(key);
            for (int j = 0; j < list.size(); j++) {
     // System.out.println("\t" + mapEntry.getKey() + "\t  " + list.get(j));
       context.write( new Text((String) list.get(j)),new IntWritable(key));     
        }
		   
        
            }
        }
            
			
			   
               } 
		   	   
 
	


