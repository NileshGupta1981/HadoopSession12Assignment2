package QuestionTimes;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class QuestionPercentMapper extends Mapper <LongWritable,Text,Text,IntWritable>
{

	IntWritable outvalue = new IntWritable();
	Text outkey = new Text();
	
	
	
	public void map(LongWritable key , Text value , Context context ) throws IOException,InterruptedException
	{
		String[] input = value.toString().split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
		String hospitalquestion = input[1];
		 outkey.set(hospitalquestion);
		 outvalue.set(1);
		context.write(outkey, outvalue);
		
	}
	
	
	
}
