package HospitalData;
import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;


public class AnserpercentReducer extends Reducer<Text,DoubleWritable,Text,DoubleWritable> 
{

	//Text outkey = new Text();
	//DoubleWritable outvalue = new DoubleWritable();
	
	
	public void reduce(Text key , Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException{
		
		double percent = 0.0;
		int count=0;
		
		
		for (DoubleWritable value:values){
			
			percent = percent+value.get();
			count = count +1 ;
			
		}
		
		double outputvalues = percent /count;
		
		context.write(key, new DoubleWritable(outputvalues));
		
	
	}
	
	
}
