package HospitalData;
 import java.io.IOException;
 import org.apache.hadoop.io.Text;
 //import org.apache.hadoop.io.IntWritable;
 import org.apache.hadoop.io.DoubleWritable;
 import org.apache.hadoop.io.LongWritable;
 import org.apache.hadoop.mapreduce.Mapper;
 
public class AnswerPercentMapper extends Mapper <LongWritable,Text,Text,DoubleWritable>
{

	//IntWritable outvalue = new IntWritable();
	DoubleWritable outvalue = new DoubleWritable();
	Text outkey = new Text();
	
	
	
	public void map(LongWritable key , Text value , Context context ) throws IOException,InterruptedException
	{
		String[] input = value.toString().split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
		//String[] input = value.toString().split(",");
		String hospitalname = input[0];
		String hospitalpercent = input[3];
		//System.out.println("Hosital percent is "+ hospitalpercent);
		 outkey.set(hospitalname);
		 outvalue.set(Double.parseDouble(hospitalpercent));
		context.write(outkey, outvalue);
		
	}
	
	
	
}
